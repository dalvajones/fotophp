<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form action="procImg.php" method="post"
    enctype="multipart/form-data">

    <div>
        <label>Imagem</label>
        <input type="file" name="imagem"/>
    </div>
    <div>
        <input type="submit" value="upload"/>
    </div>
</form>
</body>
</html>